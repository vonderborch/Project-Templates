﻿using System;

namespace $safeprojectname$
{
    class Program
    {
        static void Main(string[] args)
    {
        // insert test code here
        //var library = new Library();
        //Console.WriteLine(library.DoThing());
    }
}
}
