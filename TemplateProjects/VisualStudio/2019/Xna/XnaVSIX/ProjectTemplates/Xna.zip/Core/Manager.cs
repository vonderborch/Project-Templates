﻿namespace $safeprojectname$
{
    /// <summary>
    ///     A manager.
    /// </summary>
    public class Manager
    {
    }
}