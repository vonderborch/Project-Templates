﻿using System;
using System.Collections.Generic;
using System.Text;

namespace $safeprojectname$
{
    public class Library
    {

        public bool DoThing()
        {
            return true;
        }
    }
}
