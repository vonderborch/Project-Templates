﻿using NUnit.Framework;

namespace $safeprojectname$
{
    class LibraryTest
    {
        [Test]
        public void Test()
        {
            //var library = new Library();
            //Assert.AreEqual(true, library.DoThing());
        }
    }
}
